Subsitute API key to run script

`npm install` to install modules, npm -v 10+, node -v 20+

`npm run build` builds the ts file

`npm run test` runs the vitest suite

`npm run start` run the built js file
