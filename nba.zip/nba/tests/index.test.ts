import axios from "axios"
import {fetchTeams, fetchPlayersByTeamId, getPlayersForTeam} from "../src/index.ts"
import {vi, describe, it, expect, beforeEach, Mocked} from "vitest"

vi.mock("axios")
const mockedAxios = axios as Mocked<typeof axios>

describe("API functions", () => {
  beforeEach(() => {
    vi.clearAllMocks()
  })

  describe("fetchTeams", () => {
    it("should return a list of teams on success", async () => {
      const mockedResponse = {
        data: {
          data: [
            {
              id: 1,
              conference: "West",
              division: "Pacific",
              city: "Golden State",
              name: "Warriors",
              full_name: "Golden State Warriors",
              abbreviation: "GSW",
            },
          ],
        },
      }

      mockedAxios.get.mockResolvedValueOnce(mockedResponse)

      const result = await fetchTeams()
      expect(result).toEqual(mockedResponse.data.data)
    })

    it("should throw an error when the API call fails", async () => {
      mockedAxios.get.mockRejectedValueOnce(new Error("API error"))

      await expect(fetchTeams()).rejects.toThrow("Failed to fetch teams: Error: API error")
    })
  })

  describe("fetchPlayersByTeamId", () => {
    it("should return a list of players for a team on success", async () => {
      const mockedResponse = {
        data: {
          data: [
            {
              id: 1,
              first_name: "Stephen",
              last_name: "Curry",
              position: "G",
              height: "6-3",
              weight: "185",
              jersey_number: "30",
              college: "Davidson",
              country: "USA",
              draft_year: 2009,
              draft_round: 1,
              draft_number: 7,
              team: {
                id: 1,
                conference: "West",
                division: "Pacific",
                city: "Golden State",
                name: "Warriors",
                full_name: "Golden State Warriors",
                abbreviation: "GSW",
              },
            },
          ],
        },
      }

      mockedAxios.get.mockResolvedValueOnce(mockedResponse)

      const result = await fetchPlayersByTeamId(1)
      expect(result).toEqual(mockedResponse.data.data)
    })

    it("should throw an error when the API call fails", async () => {
      mockedAxios.get.mockRejectedValueOnce(new Error("API error"))

      await expect(fetchPlayersByTeamId(1)).rejects.toThrow("Failed to fetch players for team 1: Error: API error")
    })
  })

  describe("getPlayersForTeam", () => {
    it("should log team information and draft rounds on success", async () => {
      const teamsMockedResponse = {
        data: {
          data: [
            {
              id: 1,
              conference: "West",
              division: "Pacific",
              city: "Golden State",
              name: "Warriors",
              full_name: "Golden State Warriors",
              abbreviation: "GSW",
            },
          ],
        },
      }

      const playersMockedResponse = {
        data: {
          data: [
            {
              id: 1,
              first_name: "Stephen",
              last_name: "Curry",
              position: "G",
              height: "6-3",
              weight: "185",
              jersey_number: "30",
              college: "Davidson",
              country: "USA",
              draft_year: 2009,
              draft_round: 1,
              draft_number: 7,
              team: teamsMockedResponse.data.data[0],
            },
            {
              id: 2,
              first_name: "Klay",
              last_name: "Thompson",
              position: "G",
              height: "6-6",
              weight: "215",
              jersey_number: "11",
              college: "Washington State",
              country: "USA",
              draft_year: 2011,
              draft_round: 1,
              draft_number: 11,
              team: teamsMockedResponse.data.data[0],
            },
            {
              id: 3,
              first_name: "Draymond",
              last_name: "Green",
              position: "F",
              height: "6-6",
              weight: "230",
              jersey_number: "23",
              college: "Michigan State",
              country: "USA",
              draft_year: 2012,
              draft_round: 2,
              draft_number: 35,
              team: teamsMockedResponse.data.data[0],
            },
          ],
        },
      }

      mockedAxios.get.mockResolvedValueOnce(teamsMockedResponse)
      mockedAxios.get.mockResolvedValueOnce(playersMockedResponse)

      const consoleLogSpy = vi.spyOn(console, "log").mockImplementation(() => {})

      await getPlayersForTeam("Golden State Warriors")

      expect(consoleLogSpy).toHaveBeenCalledWith("Team Name: Golden State Warriors")
      expect(consoleLogSpy).toHaveBeenCalledWith('Draft Rounds: {"1":2,"2":1,"null":0}')

      consoleLogSpy.mockRestore()
    })

    it('should log "Team not found" if the team name does not exist', async () => {
      mockedAxios.get.mockResolvedValueOnce({data: {data: []}})

      const consoleLogSpy = vi.spyOn(console, "log").mockImplementation(() => {})

      await getPlayersForTeam("Nonexistent Team")

      expect(consoleLogSpy).toHaveBeenCalledWith('Team with name "Nonexistent Team" not found.')

      consoleLogSpy.mockRestore()
    })
  })
})
