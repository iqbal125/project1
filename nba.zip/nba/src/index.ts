import axios, {AxiosResponse} from "axios"

export interface Team {
  id: number
  conference: string
  division: string
  city: string
  name: string
  full_name: string
  abbreviation: string
}

export interface Player {
  id: number
  first_name: string
  last_name: string
  position: string
  height: string
  weight: string
  jersey_number: string
  college: string
  country: string
  draft_year: number | null
  draft_round: number | null
  draft_number: number | null
  team: Team
}

const teamName = "Golden State Warriors"

const baseURL = "https://api.balldontlie.io/v1"
const apiKey = ""
const headers = {
  Authorization: apiKey,
}

export async function fetchTeams(): Promise<Team[]> {
  try {
    const response: AxiosResponse<{data: Team[]}> = await axios.get(`${baseURL}/teams`, {headers})
    return response.data.data
  } catch (error) {
    throw new Error(`Failed to fetch teams: ${error}`)
  }
}

export async function fetchPlayersByTeamId(teamId: number): Promise<Player[]> {
  try {
    const players: Player[] = []

    const params: any = {team_ids: [teamId]}

    const response: AxiosResponse<{data: Player[]}> = await axios.get(`${baseURL}/players`, {headers, params})

    players.push(...response.data.data)

    return players
  } catch (error) {
    throw new Error(`Failed to fetch players for team ${teamId}: ${error}`)
  }
}

export async function getPlayersForTeam(teamName: string) {
  const teams = await fetchTeams()
  const selectedTeam = teams.find((team) => team.full_name.toLowerCase() === teamName.toLowerCase())

  if (!selectedTeam) {
    console.log(`Team with name "${teamName}" not found.`)
    return
  }

  const teamPlayers = await fetchPlayersByTeamId(selectedTeam.id)

  const draftRounds = {"1": 0, "2": 0, null: 0}

  for (const player of teamPlayers) {
    const round = player.draft_round === 1 || player.draft_round === 2 ? player.draft_round.toString() : "null"
    draftRounds[round]++
  }

  console.log(`Team Name: ${selectedTeam.full_name}`)
  console.log(`Draft Rounds: ${JSON.stringify(draftRounds)}`)
}

;(async () => {
  try {
    await getPlayersForTeam(teamName)
  } catch (error) {
    console.error(error)
  }
})()
